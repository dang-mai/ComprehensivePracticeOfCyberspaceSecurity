import random
import time
import mysql.connector
# import pprint

'''generate data'''
insert_data = []
for i in range(1, 101):
    birth = time.localtime(random.randint(0, 30*(365*24*60*60)))
    id_number = '2187' + str(random.randint(0, 99)) + time.strftime('%Y%m%d', birth) + str(random.randint(0, 9999))
    data_of_birth = time.strftime('%Y-%m-%d', birth)
    letters = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j',
               'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
    division = random.randint(2, 6)
    name = ''.join(random.sample(letters, division)).title() + ''.join(random.sample(letters, 8 - division)).title()
    email = name + str(random.randint(1, 9999999)) + '@' + random.choice(['163.com', 'qq.com', 'hust.edu.cn'])
    country_address = {
        'CN': ['RM 1-10,THRD,HY District,WH', 'QS 3-6,TSAD,NS District,BJ'],
        'US': ['AD 3-9,JKSD,ID District,NK', 'JK 4-3,FGHF,AF District,WG'],
        'JP': ['DG 3-8,HGJJ,DF District,DK', 'KS 7-4,SMDD,DS District,SK'],
    }
    country_phone_number = {'CN': '(086)1' + str(random.random())[2:12],
                            'US': '(001)' + str(random.random())[2:12],
                            'JP': '(080)' + str(random.random())[2:10],
                            }
    country = random.choice(['CN', 'US', 'JP'])
    phone_number = country_phone_number[country]
    address = random.choice(country_address[country])
    insert_data.append((id_number, name, phone_number, country, address, email, data_of_birth))
# pprint.pprint(insert_data)

'''execute insert'''
conn = mysql.connector.connect(user='taowangcheng', password='123456', database='Galaxy')
c = conn.cursor()
c.executemany('insert into PassengerInfo values(%s, %s, %s, %s, %s, %s, %s)', insert_data)
conn.commit()
c.close()
conn.close()

